# En gestion_libros/libros.py

class Libro:
    def __init__(self, titulo, autor, anio, genero, isbn):
        self.titulo = titulo
        self.autor = autor
        self.anio = anio
        self.genero = genero
        self.isbn = isbn

    def __str__(self):
        return f"Título: {self.titulo}, Autor: {self.autor}, Año: {self.anio}, Género: {self.genero}, ISBN: {self.isbn}"

    def to_dict(self):
        return {
            'titulo': self.titulo,
            'autor': self.autor,
            'anio': self.anio,
            'genero': self.genero,
            'isbn': self.isbn
        }
