import pandas as pd
from collections import defaultdict
from gestion_libros.libros import Libro

class Inventario:
    def __init__(self, archivo_csv):
        self.libros = {}
        self.archivo_csv = archivo_csv
        self.cargar_libros()

    def cargar_libros(self):
        try:
            datos = pd.read_csv(self.archivo_csv)
            for _, fila in datos.iterrows():
                libro = Libro(fila['titulo'], fila['autor'], str(fila['anio']), fila['genero'], fila['isbn'])
                self.agregar_libro(libro)
        except FileNotFoundError:
            pass

    def cargar_datos_csv(self, archivo_csv):
        datos = pd.read_csv(archivo_csv)
        for _, fila in datos.iterrows():
            libro = Libro(fila['titulo'], fila['autor'], str(fila['anio']), fila['genero'], fila['isbn'])
            self.agregar_libro(libro)

    def guardar_libros(self):
        datos = []
        for libro in self.libros.values():
            datos.append({
                'titulo': libro.titulo,
                'autor': libro.autor,
                'anio': libro.anio,
                'genero': libro.genero,
                'isbn': libro.isbn
            })
        df = pd.DataFrame(datos)
        df.to_csv(self.archivo_csv, index=False)

    def agregar_libro(self, libro):
        if libro.titulo in self.libros:
            raise ValueError("El libro con este título ya existe.")
        self.libros[libro.titulo.lower()] = libro
        self.guardar_libros()

    def eliminar_libro(self, titulo):
        titulo = titulo.lower()
        if titulo in self.libros:
            del self.libros[titulo]
            self.guardar_libros()
        else:
            raise ValueError("El libro con este título no se encuentra en el inventario.")

    def buscar_libro(self, titulo):
        return self.libros.get(titulo.lower(), None)

    def listar_libros(self):
        return list(self.libros.values())

    def actualizar_libro(self, titulo, **input):
        libro = self.buscar_libro(titulo)
        if libro:
            for key, value in input.items():
                if hasattr(libro, key):
                    setattr(libro, key, value)
            self.libros[libro.titulo.lower()] = libro
            self.guardar_libros()
        else:
            raise ValueError("El libro con este título no se encuentra en el inventario.")

    def estadisticas_generos(self):
        generos_stats = defaultdict(int)
        for libro in self.libros.values():
            generos_stats[libro.genero] += 1
        return generos_stats
