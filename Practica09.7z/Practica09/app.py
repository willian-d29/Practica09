import streamlit as st
import pandas as pd
import json
import matplotlib.pyplot as plt
from gestion_libros.inventario import Inventario
from gestion_libros.libros import Libro

# Configurar el inventario con el archivo CSV
archivo_csv = 'dataset.csv'
inventario = Inventario(archivo_csv)

# Configurar la aplicación Streamlit
st.title("Gestión de Libros")

# Definir las opciones como pestañas
tabs = st.tabs(["Agregar Libro", "Eliminar Libro", "Buscar Libro", "Listar Libros", "Actualizar Libro", "Estadísticas Géneros", "Cargar Datos CSV", "Exportar Inventario"])

# Pestaña para agregar un libro
with tabs[0]:
    st.header("Agregar Nuevo Libro")
    with st.form(key='agregar_libro_form'):
        titulo = st.text_input("Título")
        autor = st.text_input("Autor")
        anio = st.text_input("Año")
        genero = st.text_input("Género")
        isbn = st.text_input("ISBN")

        if st.form_submit_button("Agregar Libro"):
            try:
                if not anio.isdigit():
                    raise ValueError("El año debe ser un número.")
                libro = Libro(titulo, autor, anio, genero, isbn)
                inventario.agregar_libro(libro)
                st.success("Libro agregado exitosamente.")
            except ValueError as e:
                st.error(f"Error al agregar libro: {e}")

# Pestaña para eliminar un libro
with tabs[1]:
    st.header("Eliminar Libro")
    with st.form(key='eliminar_libro_form'):
        titulo_eliminar = st.text_input("Título del libro a eliminar")

        if st.form_submit_button("Eliminar Libro"):
            try:
                inventario.eliminar_libro(titulo_eliminar)
                st.success("Libro eliminado exitosamente.")
            except ValueError as e:
                st.error(f"Error al eliminar libro: {e}")

# Pestaña para buscar un libro
with tabs[2]:
    st.header("Buscar Libro")
    with st.form(key='buscar_libro_form'):
        titulo_buscar = st.text_input("Título del libro a buscar")

        if st.form_submit_button("Buscar Libro"):
            libro = inventario.buscar_libro(titulo_buscar)
            if libro:
                st.write("Libro encontrado:", libro)
            else:
                st.write("Libro no encontrado.")

# Pestaña para listar todos los libros
with tabs[3]:
    st.header("Listado de Libros")
    libros = inventario.listar_libros()
    if libros:
        for libro in libros:
            st.write(libro)
    else:
        st.write("No hay libros en el inventario.")

# Pestaña para actualizar un libro
with tabs[4]:
    st.header("Actualizar Libro")
    with st.form(key='actualizar_libro_form'):
        titulo_actualizar = st.text_input("Título del libro a actualizar")

        if st.form_submit_button("Buscar Libro"):
            libro = inventario.buscar_libro(titulo_actualizar)
            if libro:
                nuevo_titulo = st.text_input("Nuevo título", value=libro.titulo)
                nuevo_autor = st.text_input("Nuevo autor", value=libro.autor)
                nuevo_anio = st.text_input("Nuevo año", value=libro.anio)
                nuevo_genero = st.text_input("Nuevo género", value=libro.genero)

                if st.form_submit_button("Actualizar Libro"):
                    try:
                        kwargs = {}
                        if nuevo_titulo != libro.titulo:
                            kwargs['titulo'] = nuevo_titulo
                        if nuevo_autor != libro.autor:
                            kwargs['autor'] = nuevo_autor
                        if nuevo_anio != libro.anio:
                            if not nuevo_anio.isdigit():
                                raise ValueError("El año debe ser un número.")
                            kwargs['anio'] = nuevo_anio
                        if nuevo_genero != libro.genero:
                            kwargs['genero'] = nuevo_genero

                        inventario.actualizar_libro(titulo_actualizar, **kwargs)
                        st.success("Libro actualizado exitosamente.")
                    except ValueError as e:
                        st.error(f"Error al actualizar libro: {e}")
            else:
                st.error("El libro con este título no se encuentra en el inventario.")

# Pestaña para ver estadísticas de géneros
with tabs[5]:
    st.header("Estadísticas de Géneros")
    generos_stats = inventario.estadisticas_generos()
    if generos_stats:
        generos = list(generos_stats.keys())
        cantidades = list(generos_stats.values())

        fig, ax = plt.subplots()
        ax.pie(cantidades, labels=generos, autopct='%1.1f%%', startangle=90)
        ax.axis('equal')

        st.pyplot(fig)
    else:
        st.write("No hay libros en el inventario para mostrar estadísticas.")

# Pestaña para cargar datos desde un archivo CSV
with tabs[6]:
    st.header("Cargar Datos desde CSV")
    st.write("Sube un archivo CSV para agregar libros al inventario.")

    archivo_nuevo = st.file_uploader("Selecciona un archivo CSV", type=['csv'])
    if archivo_nuevo is not None:
        try:
            inventario.cargar_datos_csv(archivo_nuevo)
            st.success("Datos cargados exitosamente.")
        except Exception as e:
            st.error(f"Error al cargar datos: {e}")

# Pestaña para exportar el inventario como CSV o JSON
with tabs[7]:
    st.header("Exportar Inventario")
    st.write("Haz clic en el botón para exportar el inventario actual.")

    datos = []
    for libro in inventario.libros.values():
        datos.append({
            'titulo': libro.titulo,
            'autor': libro.autor,
            'anio': libro.anio,
            'genero': libro.genero,
            'isbn': libro.isbn
        })
    df = pd.DataFrame(datos)
    csv_data = df.to_csv(index=False).encode('utf-8')
    json_data = json.dumps(datos, indent=4).encode('utf-8')

    st.download_button(label="Exportar como CSV", data=csv_data, file_name='inventario_libros.csv', mime='text/csv')
    st.download_button(label="Exportar como JSON", data=json_data, file_name='inventario_libros.json', mime='application/json')
